package test.com.sample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Sample extends HttpServlet{
	 @Resource(mappedName = "jms/GlassFishBookConnectionFactory")
	  private static ConnectionFactory connectionFactory;
	 @Resource(mappedName = "jms/GlassFishBookQueue")
	  private static Queue queue;


  public void doGet(HttpServletRequest request,
          HttpServletResponse response)
  throws ServletException, IOException
{
	
	  
	  Connection connection;
	    MessageConsumer messageConsumer;
	   // TextMessage textMessage = null;
	    boolean goodByeReceived = false;
	    try
	    {
	    	 connectionFactory = new com.sun.messaging.ConnectionFactory();
	      connection = connectionFactory.createConnection();
	      Session session = connection.createSession(false,
	        Session.AUTO_ACKNOWLEDGE);
	      queue= new com.sun.messaging.Queue();
	      messageConsumer = session.createConsumer(queue);
	      String s=null;
	      connection.start();
	      while (!goodByeReceived)
	      {
	        System.out.println("Waiting for messages...");
	        TextMessage textMessage = (TextMessage) messageConsumer.receive();
	        if (textMessage != null)
	        {
	          System.out.print("Received the following message: ");
	         // System.out.println(textMessage.getText());
	          s=textMessage.getText();
	          System.out.println(s);
	        }
	        if (textMessage.getText() != null)
	        {
	          goodByeReceived = true;
	        }
	      }
	      messageConsumer.close();
	      session.close();
	      connection.close();
	      
	   // Set refresh, autoload time as 5 seconds
	      response.setIntHeader("Refresh", 4);
	      response.setContentType("text/html");

	      PrintWriter out = response.getWriter();
		  String title = "Using GET Method to Read Form Data";
	      String docType =
	      "<!doctype html public \"-//w3c//dtd html 4.0 " +
	      "transitional//en\">\n";
	      out.println(docType +
	                "<html>\n" +
	                "<head><title>" + title + "</title></head>\n" +
	                "<body bgcolor=\"#f0f0f0\">\n" +
	                "<h1 align=\"center\">" + title + "</h1>\n" +
	                "<ul>\n" +
	                "  <li><b>First Name</b>: "
	                + "\n" +
	                "  <li><b>Last Name</b>: "
	                + s+ "\n" +
	                "</ul>\n" +
	                "</body></html>");
	    }
	    catch (JMSException e)
	    {
	      e.printStackTrace();
	    }
	  // Set response content type
     
	  
}
  public void doPost(HttpServletRequest request,
          HttpServletResponse response)
throws ServletException, IOException {
doGet(request, response);
} 
  
  public void getMessages()
  {
    Connection connection;
    MessageConsumer messageConsumer;
    TextMessage textMessage;
    boolean goodByeReceived = false;
    try
    {
    	connectionFactory = new com.sun.messaging.ConnectionFactory();
      connection = connectionFactory.createConnection();
      Session session = connection.createSession(false,
        Session.AUTO_ACKNOWLEDGE);
      queue= new com.sun.messaging.Queue();
      messageConsumer = session.createConsumer(queue);
      connection.start();
      while (!goodByeReceived)
      {
        System.out.println("Waiting for messages...");
        textMessage = (TextMessage) messageConsumer.receive();
        if (textMessage != null)
        {
          System.out.print("Received the following message: ");
          System.out.println(textMessage.getText());
          System.out.println();
        }
        if (textMessage.getText() != null
          && textMessage.getText().equals("Good bye!"))
        {
          goodByeReceived = true;
        }
      }
      messageConsumer.close();
      session.close();
      connection.close();
    }
    catch (JMSException e)
    {
      e.printStackTrace();
    }
  }
}